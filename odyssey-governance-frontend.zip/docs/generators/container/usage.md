### Container
```bash
yarn run new
container
```

Создает контейнер

<details>
  <summary>Структура добавляемых файлов</summary>

  ```bash
  my-project
  |-- src
  |   |-- containers
  |   |   |-- название контейнера
  |   |        |-- index.tsx
  |   |   |-- index.ts
  ```
</details>